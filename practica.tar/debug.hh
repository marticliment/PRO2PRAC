#ifndef DEBUG_HH
#define DEBUG_HH

#include <iostream>

using namespace std;

void Log(int number);
void Log(string message);
void Error(int number);
void Error(string message);

#endif